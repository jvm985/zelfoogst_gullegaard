(function($) {
    'use strict';

    $(function() {
        const root = $('#gs-recipes-root');
        if (!root.length) return;

        let recipes = [];
        let harvestableCrops = [];

        init();

        async function init() {
            root.html('<div class="gs-loading">Recepten en gewassen laden...</div>');
            
            try {
                // Fetch harvestable crops from cultivations
                const cultivations = await $.get(gs_vars.api_url + '/cultivations');
                const now = new Date();
                harvestableCrops = cultivations
                    .filter(c => c.harvestDate && new Date(c.harvestDate) <= now && (!c.endDate || new Date(c.endDate) > now))
                    .map(c => c.crop.id);

                // Fetch recipes
                const res = await $.get(gs_vars.api_url + '/recipes');
                recipes = res;
                
                renderFilters();
                renderRecipes(recipes);
            } catch (err) {
                root.html('<p>Fout bij laden van data.</p>');
            }
        }

        function renderFilters() {
            const filterHtml = `
                <div class="gs-filters">
                    <button id="gs-filter-all" class="gs-btn active">Alle Recepten</button>
                    <button id="gs-filter-harvestable" class="gs-btn">Nu Oogstbaar 🌿</button>
                </div>
            `;
            root.before(filterHtml);

            $('#gs-filter-all').on('click', function() {
                $('.gs-btn').removeClass('active');
                $(this).addClass('active');
                renderRecipes(recipes);
            });

            $('#gs-filter-harvestable').on('click', function() {
                $('.gs-btn').removeClass('active');
                $(this).addClass('active');
                const filtered = recipes.filter(r => {
                    return r.crops && r.crops.some(cropId => harvestableCrops.includes(parseInt(cropId)));
                });
                renderRecipes(filtered);
            });
        }

        function renderRecipes(items) {
            root.empty();
            if (items.length === 0) {
                root.append('<p class="gs-empty">Geen recepten gevonden.</p>');
                return;
            }

            const grid = $('<div class="gs-recipes-grid"></div>');
            items.forEach(recipe => {
                const isHarvestable = recipe.crops && recipe.crops.some(cropId => harvestableCrops.includes(parseInt(cropId)));
                
                const card = $(`
                    <div class="gs-recipe-card ${isHarvestable ? 'is-harvestable' : ''}">
                        <h3 class="gs-recipe-title">${recipe.title}</h3>
                        <div class="gs-recipe-content">${recipe.excerpt}</div>
                        ${isHarvestable ? '<div class="gs-harvest-badge">Nu Oogstbaar</div>' : ''}
                        <a href="${recipe.link}" class="gs-recipe-link">Bekijk Recept</a>
                    </div>
                `);
                grid.append(card);
            });
            root.append(grid);
        }
    });

})(jQuery);
