<?php

class GS_API {
	public function register_routes() {
		$version = '1';
		$namespace = 'gs-harvest/v' . $version;

		register_rest_route( $namespace, '/fields', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_fields' ),
			'permission_callback' => '__return_true',
		));

        register_rest_route( $namespace, '/fields/(?P<id>\d+)/blocks', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_field_blocks' ),
			'permission_callback' => '__return_true',
		));

        register_rest_route( $namespace, '/blocks', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'save_block' ),
			'permission_callback' => array( $this, 'check_admin_permission' ),
		));

        register_rest_route( $namespace, '/cultivations', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_cultivations' ),
			'permission_callback' => '__return_true',
		));

        register_rest_route( $namespace, '/recipes', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_recipes' ),
			'permission_callback' => '__return_true',
		));

        register_rest_route( $namespace, '/crops', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_crops' ),
			'permission_callback' => '__return_true',
		));
	}

    public function check_admin_permission() {
        return current_user_can( 'manage_options' );
    }

    public function get_cultivations() {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_cultivations';
        $cults = $wpdb->get_results( "SELECT * FROM $table" );
        
        $data = array();
        foreach ( $cults as $cult ) {
            $crop = get_post( $cult->crop_id );
            $data[] = array(
                'id' => $cult->id,
                'crop' => array(
                    'id' => $cult->crop_id,
                    'name' => $crop ? $crop->post_title : 'Onbekend',
                ),
                'startDate' => $cult->start_date,
                'endDate' => $cult->end_date,
                'harvestDate' => $cult->harvest_date,
            );
        }
        return rest_ensure_response( $data );
    }

    public function get_recipes() {
        $recipes = get_posts( array( 'post_type' => 'gs_recipe', 'numberposts' => -1 ) );
        $data = array();
        foreach ( $recipes as $recipe ) {
            $crops = get_post_meta( $recipe->ID, '_gs_recipe_crops', true );
            $data[] = array(
                'id'      => $recipe->ID,
                'title'   => $recipe->post_title,
                'excerpt' => get_the_excerpt( $recipe->ID ),
                'link'    => get_permalink( $recipe->ID ),
                'crops'   => is_array( $crops ) ? $crops : array(),
            );
        }
        return rest_ensure_response( $data );
    }

	public function get_fields() {
		$fields = get_posts( array( 'post_type' => 'gs_field', 'numberposts' => -1 ) );
		$data = array();
		foreach ( $fields as $field ) {
			$data[] = array(
				'id'   => $field->ID,
				'name' => $field->post_title,
			);
		}
		return rest_ensure_response( $data );
	}

    public function get_field_blocks( $request ) {
        global $wpdb;
        $field_id = $request['id'];
        $table = $wpdb->prefix . 'gs_blocks';
        $blocks = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE field_id = %d", $field_id ) );
        
        $data = array();
        foreach ( $blocks as $block ) {
            $table_beds = $wpdb->prefix . 'gs_beds';
            $beds = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_beds WHERE block_id = %d", $block->id ) );
            
            $beds_data = array();
            foreach ( $beds as $bed ) {
                $table_cults = $wpdb->prefix . 'gs_cultivations';
                $cults = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_cults WHERE bed_id = %d", $bed->id ) );
                
                $cults_data = array();
                foreach ( $cults as $cult ) {
                    $crop = get_post( $cult->crop_id );
                    $cults_data[] = array(
                        'id' => $cult->id,
                        'crop' => array(
                            'id' => $cult->crop_id,
                            'name' => $crop ? $crop->post_title : 'Onbekend',
                        ),
                        'startDate' => $cult->start_date,
                        'endDate' => $cult->end_date,
                        'harvestDate' => $cult->harvest_date,
                    );
                }

                $beds_data[] = array(
                    'id' => $bed->id,
                    'name' => $bed->name,
                    'cultivations' => $cults_data,
                );
            }

            $data[] = array(
                'id' => $block->id,
                'name' => $block->name,
                'row' => $block->row_index,
                'col' => $block->col_index,
                'beds' => $beds_data,
            );
        }
        return rest_ensure_response( $data );
    }

    public function save_block( $request ) {
        global $wpdb;
        $params = $request->get_json_params();
        $table = $wpdb->prefix . 'gs_blocks';
        
        if ( isset( $params['id'] ) ) {
            $wpdb->update( $table, array(
                'name' => $params['name'],
                'row_index' => $params['row'],
                'col_index' => $params['col'],
            ), array( 'id' => $params['id'] ) );
            return rest_ensure_response( array( 'success' => true, 'id' => $params['id'] ) );
        } else {
            $wpdb->insert( $table, array(
                'field_id' => $params['field_id'],
                'name' => $params['name'],
                'row_index' => $params['row'],
                'col_index' => $params['col'],
            ) );
            return rest_ensure_response( array( 'success' => true, 'id' => $wpdb->insert_id ) );
        }
    }

    public function get_crops() {
        $crops = get_posts( array( 'post_type' => 'gs_crop', 'numberposts' => -1 ) );
        $data = array();
        foreach ( $crops as $crop ) {
            $data[] = array(
                'id' => $crop->ID,
                'name' => $crop->post_title,
            );
        }
        return rest_ensure_response( $data );
    }
}
